# Materialize Pagination

<p align="left">
  <img src="/../screenshots/screenshot_2.png?raw=true" height="110px" align="left">
</p>

Materialize Pagination is a jQuery plugin that provides behaviour and  rendering of the [Materialize Pagination component][1].

**See [official page] (http://mirjamsk.github.io/materialize-pagination/) containing a demo & getting started guide**
[1]: http://materializecss.com/pagination.html
